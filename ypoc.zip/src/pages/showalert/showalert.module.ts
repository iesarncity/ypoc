import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ShowalertPage } from './showalert';

@NgModule({
  declarations: [
    ShowalertPage,
  ],
  imports: [
    IonicPageModule.forChild(ShowalertPage),
  ],
})
export class ShowalertPageModule {}
